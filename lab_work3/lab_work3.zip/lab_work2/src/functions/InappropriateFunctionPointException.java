package functions;

public class InappropriateFunctionPointException extends Exception {
    public InappropriateFunctionPointException(String message){
        super(message);
    }
}
